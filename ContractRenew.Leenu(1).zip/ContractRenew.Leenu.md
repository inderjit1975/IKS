﻿No. CA/B/                                                                                                                      Date: 



To

The Principal,

Guru Nanak Dev Engineering College,

Ludhiana.


Through: HOD Computer Applications.

Subject: **Regarding Renewal of Contract as Adjunct faculty in BCA Program**

Respected Sir,



I, **Dr. Leenu Anand**, have been performing my duties as Adjunct faculty with reference to your letter no. LA/E/1211-A since Nov. 11, 2020 for BCA Program of your prestigious institution. My contract is going to expire on 31-01-2021.

I wish to continue my services in this college. So kindly renew my contract.



Yours Sincerely,


(Dr. Leenu Anand)

Adjunct Faculty

Department of Computer Applications,

GNDEC, Ludhiana









